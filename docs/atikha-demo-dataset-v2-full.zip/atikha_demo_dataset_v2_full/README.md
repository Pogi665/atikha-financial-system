# Atikha Finance — Full Synthetic Presentation Dataset V2

**Dataset ID:** `ATIKHA-DEMO-V2-FULL`  
**History:** November 2025 through October 2026  
**Forecast demo month:** November 2026  
**All data is fictional.**

This supersedes V1 as the authoritative final presentation/demo dataset.

## Scale

- 120 incoming-fund receipts
- 360 recognized-expense events
- 24 General Journal reclassifications
- 22 cash advances
- 15 correction chains
- 220 supporting-evidence metadata rows
- 36 OCR review scenarios
- 221 budget allocation rows
- 14 report review rows
- 64 fictional parties

The goal is a system that looks genuinely used for a year, not thousands of meaningless random rows.

## Financial oracle

Total incoming funds: PHP 5,800,000.00  
Total recognized expenses: PHP 3,136,100.00

Use `monthly_expected_summary.csv` as the monthly validation oracle.

`recognized_expenses.csv` is the final intended recognized-expense state. Liquidation rows recognize expense but are not a second cash payment. Releases and returns remain separate cash movements.

Corrections must use Original → Reversal → Replacement and finish at the values in `recognized_expenses.csv`.

General Journal reclassifications have zero organization-wide recognized-expense effect.

## Forecast demo

The organization has 12 complete months of history.

November 2026 benchmark candidates:
- Last complete month: PHP 307,250.00
- 3-month moving average: PHP 298,433.33
- Weighted 3-month average: PHP 301,366.67
- 6-month linear trend candidate: PHP 315,486.67
- Approved November budget: PHP 330,000.00

These are independent validation benchmarks, not forced selected outputs.

`FAM-YTH` starts only in Sep 2026 and must remain a truthful **Insufficient history** granular forecast case.

## Safety

Do not seed protected `atikha_finance` during the current implementation authorization. Use only a verified disposable/demo DB.

Map account/project/party business keys to the current local schema. Prefer supported domain/application writers and current fixture helpers so accounting, audit, recovery, budget and advance invariants remain true.

Keep hostile technical fixtures separate from this polished presentation dataset.
