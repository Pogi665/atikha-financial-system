# Control-State Warnings

These are presentation safeguards for the later review, not new accounting policy.

| Risk from simplifying | Required representation |
| --- | --- |
| A required advance account disappears under advanced options | Open Accounting Details until the explicit selection is valid. It is a designated active noncash Debit-normal Asset, never a liability. No inferred default policy. |
| Reconciliation looks healthy because its details are hidden | Keep discrepancy/unavailable summary visible; last verified time and existing action blockers remain. Loading is neutral. |
| Historical balances accidentally start current settlements | Show the as-of date and offer Open Current Advance; use server eligibility. |
| Partial and Overdue become mutually exclusive | Preserve settlement status plus overdue condition. Show both when appropriate. |
| Liquidation Amount Used hides liability treatment | Review gross costs, liability credits and net reduction distinctly. Keep required notes and complete evidence coverage per eligible debit. |
| A reviewed image is mistaken for confirmed cash-return proof | Keep explicit return-proof confirmation and required reviewed informational evidence. No cost-allocation coverage substitute. |
| Shared evidence is reused without ownership/association checks | Preserve reservations, privacy, correction association, re-review and reuse restrictions. Document itemization is separate from monetary coverage. |
| Draft or proposed values look effective/posted | Label Draft / Not Recorded Yet; no official submitted version before submission. Count posted advance operations only. |
| Blank budget cells become zero | Preserve no allocation separately from an explicit zero. Missing utilization is N/A, not 0%. |
| Payments are used as recognized budget actuals | Preserve signed journal-based expense actuals, corrections, refunds and unallocated spending. No accounting calculation redesign. |
| A submitted budget silently replaces approval | Continue showing the current effective approval until an eligible Management decision. Stale basis blocks approval. |
| Reports are reviewed from live data instead of the exact copy | Decision target is the immutable Submitted Copy. Working Figures is separate. Surface changed-source and current-cycle blockers. |
| Mark Reviewed closes a month | Separate review from authorized close/reopen workflow, reasons and affected-month dependencies. |
| OCR verification implies posting or acceptance | Suggestions stay non-authoritative. Item review remains optional where currently optional; confirmation saves document details only. Continue opens the existing General Journal route. |
| Correction preview marks the original already corrected | Original remains Posted during preview. Reversal is not cash returned. Mark Corrected only after successful atomic posting. Reverse-only has no replacement. |
| A retry creates another transaction | Use existing recover/check-original-result flows after uncertain writes. Preserve drafts and review refresh requirements. |
| Setup simplification silently chooses policy | Preserve explicit cash/statement/flow mappings and exception allocations. Draft changes are not effective before submission. |
| A new button creates new authority | Server roles, feature gates, protected-account rules, MFA, CSRF and validation remain authoritative. UI visibility is not authorization. |
| A queue invents missing submitter/date fields | Read metadata from the exact existing submission; use Unavailable when not supplied. A read-only query extension may be needed later. |
| Search, totals and export scope disagree | Ledger search filters rows only; full-period running and ending balances retain their existing basis. Label matching-row export versus full-period print. |
| An unavailable module appears empty | Show Unavailable / Try Again and retain the dated last successful snapshot. Never replace errors with reassuring zeros. |
| Image-generated text contradicts the rules | The written design reference is authoritative. Do not implement helper-text errors, required-star errors or speculative sample mappings from mockups. |

No production writes, execution or permission changes were performed. The package stops at design review.
