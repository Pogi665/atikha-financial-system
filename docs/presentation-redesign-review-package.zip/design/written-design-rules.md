# Design Reference

Atikha Finance - Refined Client Experience | Design extension proposal | 24 October 2026

## 1. Product and source rules

Simple on the outside, powerful underneath. Guided forms perform accounting tasks; familiar worksheets review financial information. Apply one approved visual direction, not new alternatives. Preserve all accounting, authorization, evidence, audit and concurrency checks. Layout changes do not change eligibility.

The approved foundation sets the visual target. The source PDF supplies existing workflow meaning. The read-only GitHub `main` inspection supplies verified route/guard context. Local unpushed differences remain unknown. Written rules here take precedence over incidental generated-image labels; synthetic values are examples, not calculation definitions.

## 2. Navigation and shell

| Surface | Final treatment |
| --- | --- |
| Admin primary | Dashboard; New Transaction; Transactions; Cash Advances; Budgets; Reports; Messages. |
| New Transaction | Record a Payment; Record Money Received; General Journal Entry; Scan Receipt; My Drafts. |
| Transactions | Find a Transaction; Cash Receipts Book; Cash Disbursements Book; General Ledger. |
| Admin secondary | Separate bottom Setup and Administration. Each appears once. |
| Setup | Accounting Setup; Reporting Setup; Chart of Accounts. |
| Administration | User Management; Audit Trail. |
| Management | Dashboard; Review Queue; Reports; Budgets; Cash Advances; Messages. No authoring or setup. |
| Active location | Forest-green text/icon, pale-sage surface, 3 px left indicator; semantic current-page state. |
| Child navigation | Expand only the current group. Parent has a labeled disclosure control and expanded state; child links remain ordinary links. A task hub may show tasks in its main area without repeating an expanded child list. |
| Context | Use a short breadcrumb when returning to a selected advance, report copy or draft. Preserve filters, active tab and scroll when returning. |

Light sage sidebar; white header; warm off-white canvas. Wordmark and primary actions carry deep green. No dark full-height rail, dark masthead, forecast controls or decorative animation. Sidebar scrolls independently when necessary; its secondary links remain reachable. Primary navigation uses full names, not CRB/CDB abbreviations.

Stored roles remain `Admin` and `Management`. Existing organization-approved display labels are presentation only. Do not create a Staff role or widen a permission because a mockup displays an action.

## 3. Typography, spacing and colors

Use Inter when available, with a system sans-serif fallback. Tabular lining figures for money, dates and quantities; never encode values in an image. Font weight: body 400, controls 500, headings 600, key values 650-700. Line height: body 1.5, labels 1.35, headings 1.2.

| Token | Size / use |
| --- | --- |
| Page title | 28 px / 34 px; one per page. |
| Section heading | 18 px / 26 px. |
| Body and field value | 16 px / 24 px. |
| Label and table text | 14 px / 20 px; financial tables never shrink below 14 px. |
| Helper / critical feedback | 14 px / 20 px. Secondary timestamps may use 12 px / 18 px; never use 12 px for errors or required instructions. |
| KPI value | 28 px / 34 px; leading cash value may be 32 px, not an oversized hero. |
| Space scale | 4, 8, 12, 16, 24, 32, 48 px. Page gap 24; related field gap 16; section gap 24-32. |
| Shape | Controls 6 px radius; cards/drawers 8 px; badges pill or 4 px. One restrained surface layer; no cards inside cards. |

| Color role | Foreground / background | Meaning |
| --- | --- | --- |
| Brand | #164B3B / #FFFFFF | Primary action and identity. |
| Success | #166534 / #DCFCE7 | Recorded, reviewed, approved, settled when verified. |
| Pending | #854D0E / #FEF3C7 | Awaiting Review, Partial, attention. |
| Error / deficit | #B42318 / #FEE4E2 | Error, overdue, over budget, deficit or returned item needing correction. |
| Information / Read Only | #334155 / #EAF0F6 | Neutral information and immutable record state. |
| Canvas / surface / sidebar | #F8F9F5 / #FFFFFF / #EDF4EE | Calm base surfaces. |
| Text / muted text | #172F27 / #52645B | Main content / secondary content. |
| Border / input border | #D8E2DA / #7C8A84 | Decorative separation / perceivable field boundary. |
| Focus | #2563EB with white separation | 2 px visible ring plus 2 px offset. |

Color is never the only state cue. Use the state word and an appropriate icon. Ordinary expenses are neutral, not errors. Negative net result retains its minus sign and red treatment. Missing, loading, zero and unavailable are different states. Contrast checks cover specified token pairs only, not complete accessibility compliance.

## 4. Buttons, badges and feedback

| Component | Rule |
| --- | --- |
| Primary | Solid brand green, white label, minimum 44 px height. One dominant action per active stage. |
| Secondary | White surface, perceivable border, dark-green label. Used for Save Draft, Back or a companion task. |
| Tertiary | Underlined text or quiet labeled icon action; retain visible keyboard focus. |
| Destructive | Red outline/text; reserve for genuinely destructive or consequential negative actions, not ordinary expense entry. |
| Disabled | Muted text #59675F on #E5EAE6; remain understandable. Explain the relevant eligibility blocker beside the action. |
| Busy | Label changes to a specific action such as Saving Draft; suppress duplicate submission. Announce progress without claiming success. |
| Row menu | One labeled Actions menu per row. Never rely on hover; no Edit/Disable/More button wall. |

Draft is slate; Submitted/Awaiting Review is amber; Approved/Reviewed/Settled is success green; Returned/Overdue is red with words. Partial is amber; Outstanding is neutral or amber according to task context. Overdue is a separate condition that may coexist with Partial. Open is neutral; Closed is slate with a lock, not automatically success. Read Only uses slate-blue plus lock. Effective is a separate qualifier from Approved; a superseded approved budget must not look current.

Feedback: success says what completed and links to the exact result; warning names the issue and next step; error preserves input and gives a recovery action; information adds brief context. Loading uses a stable labeled placeholder. A failed load is not an empty state. Failed refresh retains the last successful snapshot, clearly marked with its date and refresh failure. A successful network response alone is not proof a financial operation posted.

Empty states: one specific sentence and a relevant action. Example: No Drafts to Finish / Record a Payment. No Approved Budget must not display 0% utilization or invented bars. No Search Matches is different from No Transactions in This Period.

## 5. Forms and progressive disclosure

Use visible labels, 44 px controls, consistent input boundaries and a quiet optional marker. Currency fields have a PHP prefix, two-decimal review display and right-aligned values; retain the existing server amount parser and exact-decimal calculations. Date controls show an unambiguous human date and keep the underlying ISO value. Selects support keyboard operation. Search has a persistent label and clear scope.

Transaction forms follow Details -> Review -> Recorded. Save Draft is distinct from confirmation. The Review stage shows the complete balanced journal and evidence result before the existing confirm-and-record action; the normal Details view can omit journal lines. A review token expiring, a stale draft, changed evidence or changed balances requires a fresh review, not silent posting. Preserve entered values.

Validation: focus a concise error summary, associate each error with its field, expose the affected section, and offer specific recovery. Do not disable Review so early that validation becomes undiscoverable; keep it available to reveal errors unless a real prerequisite such as an unconfirmed required proof is clearly explained. Required selections must never be hidden in a collapsed section without an attention cue.

| Disclosure | Treatment |
| --- | --- |
| More Options | References, split allocation and advanced journal controls; collapsed for ordinary entry. |
| Accounting Details | Read-only journal detail or advanced setup fields. Required unresolved controls open automatically. |
| Supporting Documents | Optional for ordinary payments/releases; open and visible for required liquidation coverage or return proof. |
| Advanced setup | Focused steps/tabs, not all configuration forms stacked on one page. |
| Critical warning | Visible summary outside the collapsed panel; details may expand. Never hide an eligibility blocker. |

Accordions use a real button, expanded state and keyboard activation. Preserve expanded-state choices during a validation cycle. Tab changes must not silently discard unsaved values or clear the original review target.

## 6. Tables, worksheets and cards

| Pattern | Treatment |
| --- | --- |
| Normal table | 14 px text, 44-48 px rows, clear headers, light horizontal separators, optional zebra tint. Search/filter above. |
| Financial worksheet | Full available width, aligned numeric columns, explicit PHP units and period/account context. Description left, amounts right. Distinguish opening, period movements and ending. |
| Headers | Sticky inside the table viewport when useful. Pin account/description columns only if doing so leaves adequate reading width. |
| Totals | Sage tint and a stronger top rule; label Full Period Totals / Ending Balance where appropriate. Distinguish filtered subtotal from full-period totals. |
| Selected row | Soft sage surface plus selection indicator; not just color. Selection does not authorize editing. |
| Editable draft cell | Visible input boundary and focus ring, accessible row/column label, explicit Draft state. Budget cells only where the workflow allows. |
| Posted cell | Plain text with Read Only state; no input border, formula bar, fill handle or cell-edit cursor. View opens details. |
| Empty table | Contextual empty sentence inside the table region, maintaining headers where useful. |
| Pagination | Showing X-Y of Z, labeled Previous/Next, selectable size where currently supported. Preserve filters and valid server limits. Do not invent unlimited loading. |

Budget grids preserve blank versus explicit zero. Actuals are signed recognized expenses from posted journal lines; they are not payment-book totals. Null allocation/remaining/utilization stays unavailable, not zero. Values above 100% and negative actuals remain valid representations of existing calculations.

Ledger search filters visible movements, not the account period or the running-balance calculation. Display Account + From/To, opening balance, debit/credit movements, running balance and full-period ending. Export matching rows and print full period remain distinct scopes. No-results search retains full-period totals. Do not force arbitrary 10-row pagination on modules with different existing validated page-size options.

KPI cards: six or fewer compact, balanced values; title, amount and short period label. Needs Attention uses a grouped list with separators, not a card per sentence. Review items identify type, period, submitter, date, exact copy and next action. Summary cards group related facts once. Empty cards have one actionable next step. Avoid duplicate facts and nested surface stacks.

## 7. Cash advance lifecycle

Register: prioritize Employee, Purpose, Project, Released, Liquidated, Returned, Outstanding, Due Date and Status. Filters include as-of date, employee, project and status; advanced account filters may collapse. Reconciliation Details stays secondary, but a failed/unavailable verification has an immediate visible summary and blocks actions wherever existing rules require it. Show last-verified time; never assume green health while loading.

Detail: employee/purpose/project/status header; four balance KPIs; posted Release / Liquidation / Cash Return timeline; per-operation View Transaction and Accounting Details. Include corrections and reversals in the timeline when present. Due-date and correction history remains accessible. Admin actions come from current eligibility, not from the visual state alone. Historical as-of views do not start settlements; provide Open Current Advance. Management has read-only visibility and permitted detail links, not authoring/correction/deadline controls or unauthorized images.

Release: Date, Employee, Purpose, Project, Amount, Pay From and Due Date. The currently required Advance Account is an explicit selection. Place it in an OPEN Accounting Details section until valid; do not invent a default-account policy. It must remain an eligible designated active noncash Debit-normal Asset. Release creates an advance, not an expense. Optional external approval metadata remains optional and does not become a new system approval workflow.

Liquidation: linked employee/advance and outstanding balance, Date, Purpose, Cost / Asset Account, Amount Used, Project and required Supporting Documents. Support multiple cost lines. More Accounting Options exposes eligible liability credits/withholding with required notes. Gross eligible debits, liability credits and net advance reduction remain distinct in advanced review; do not label all three Amount Used. Every eligible cost/asset debit must be fully covered by reviewed monetary evidence. Informational documents do not add coverage. Used/excluded image amounts cannot be casually reused for another liquidation.

Return: linked advance, Date, Purpose, Cash Returned, Receive Into, origin project context and reviewed proof. Keep explicit return-proof confirmation visible. A reviewed upload is not itself return confirmation. This is informational proof, not monetary cost allocation. Amount and chronology/outstanding guards remain unchanged. Correct Transaction attaches to a specific posted operation and opens the existing correction path.

## 8. Budgets and Management review

Monthly Budgets: period selector, effective approved-budget label and quiet version metadata; Approved / Actual / Remaining / Utilization; read-only worksheet by expense account and project. Pending drafts/submissions appear separately. A new submission does not replace the approved budget. History distinguishes effective approval, superseded approval, returned submission and private draft.

Prepare Budget Draft: editable allocation matrix with account rows and project columns, Organization Operations bucket, optional note and draft total. Blank means no allocation, zero means explicit zero. Actuals and current approved figures are read-only context. Save Draft -> Review Budget -> Submit for Approval. A draft has no official submitted version number merely because it was saved. Review presents proposed allocations and the approved basis without changing either.

Budget Review: Management opens the exact submitted version, sees submitter/date/current approved context, then Approve Budget or Return With Reason. Return requires a reason. A stale submission whose approval basis changed cannot be approved; show the blocker and allow the existing return path. Do not add new approval thresholds or reviewer roles.

Review Queue: actionable Budgets Awaiting Review, Reports Awaiting Review and permitted messages/other items only. Every item shows type, period, submitter, submitted date, status and Open action. Do not mix blind decisions into the queue. Retired Incoming Funds/Expenses sections move to secondary archive/history where existing readers support them. Metadata not currently returned by a queue endpoint requires a read-only projection from the existing submission; show Unavailable until verified, never guess a submitter.

Report Review: exact Submitted Copy, its version and current eligibility; all eight reports remain reachable through four primary tabs and Accounting Details. Mark Reviewed and Return With Reason are report decisions, not budget approvals or period closing. Working Figures is an explicit different view. Stale source, reopened-cycle or incomplete-report blockers remain visible. Management-only Close/Reopen stays in a separate period workflow with affected months, reason and existing eligibility checks. Admin sees status/history, not unauthorized close controls.

## 9. Receipts, evidence and corrections

Scan Receipt: Upload -> Review Details -> Continue to Transaction. Show upload area, real accepted types/limits, private preview and reading state. Verified current upload guidance is JPG/PNG/WebP, up to 8 MiB and 20 megapixels; do not add PDF/HEIC support. If unavailable: Automatic reading was unavailable. You can continue by entering the details manually. The current continuation opens General Journal; changing the label does not create a new payment/receipt posting route.

Receipt-item review: original image beside OCR Suggestions and User-Confirmed Details. Suggestions are never implicitly confirmed. Preserve merchant, reference, date, PHP currency, document total, printed item description/quantity/amount, completeness and discrepancy explanation. Printed quantity is a note, not an amount multiplier. Complete items must match the total; incomplete itemization requires a reason. Explicit inspection confirmation remains. Optional item review must not become a newly mandatory workflow. Saving document details posts no financial entry and does not replace monetary evidence allocation in the transaction. Changes require a fresh financial review. Posted evidence is read-only; correction-context reuse follows association permissions and re-review rules.

Corrections: original business summary first; correction reason and replacement details; earlier-date explanation when the existing rule requires it. Choose reverse-and-replace or the separate reverse-only path before the current draft mode becomes fixed. Details -> Review -> Recorded. Review shows Original Transaction / Reversal / Corrected Transaction, each with optional Accounting Details. A reversal is an accounting offset, not an actual cash return. Original stays Posted during preview; show Corrected only after confirmed success. Reverse-only has no replacement, and advance corrections retain linked lifecycle constraints. Reused evidence requires a fresh review and explanation where required. An uncertain submit result uses the existing recovery lookup; do not encourage duplicate posting.

## 10. Setup and Administration

Accounting Setup has Projects / Parties / Advance Accounts tabs. Each shows current records, relevant filters, one Add action and a focused editor. Projects retain name/code/description/status. Parties retain Person/Organization, name/reference/description/status. Advance designation retains eligible account, operation and required reason. Disabling/reclassification protections and used-account constraints remain enforced. Do not label an advance control account a liability or allow ordinary entries to use it.

Reporting Setup is an advanced Admin destination, separate from Reports. Status rows show Cash Accounts, Statement Mappings, Cash Flow Classifications and exceptions needing attention with the applicable period/configuration. Review Reporting Setup opens focused Period / Accounts and Mappings / Exceptions / Review steps. Retain effective month, reporting-year start, configured cash accounts, statement mapping and cash-flow treatment. Exception tools still cover opening/closing purposes, mixed cash movements/advance-funded investing and noncash reclassification. Draft does not change the submitted setup. Submit Setup follows existing review and does not edit posted journals. Illustrative mappings are not accounting policy recommendations.

Chart of Accounts: Search, Account Type, Status, Add Account; Assets/Liabilities/Equity/Income/Expenses groups. Quiet code, normal balance, cash designation and active state. One Actions menu. Respect used-account restrictions and require the existing reasons/confirmations. No new bank-feed or permanent bank-ledger management.

User Management: Name, Email, Role, Status, Created Date, Actions; Add User primary; Password Reset Requests secondary tab/count. Reuse the current Admin/Management permissions and existing role labels. Create/edit form preserves server constraints and field errors. Disable/reactivate preserves historical identities; show protected/self/last-admin restrictions from the server. Password/MFA/reset controls are not weakened by the new surface.

## 11. Dialogs and interaction containers

| Container | Use / behavior |
| --- | --- |
| Modal | Short confirmation, return reason, simple Add User/account form when it fits. Labeled dialog, focus trap, initial focus, Escape/Cancel and return to trigger. Confirming a financial action still requires the existing review. |
| Side drawer | Project/party/account metadata create/edit while preserving table context; about 440-520 px on desktop. Use full page if fields become long. |
| Inline expansion | Journal detail, evidence summary, reconciliation, row history or advanced options. Keep errors and state summaries outside the collapsed body. |
| Full page | Transaction entry/review, correction comparison, image/evidence review, editable budget grid, advanced reporting setup and period close/reopen. Never cram a worksheet or complex accounting review into a tiny modal. |

Use one active overlay at a time. Opening an editor closes a row menu safely. Cancel restores tab/filter/focus. Unsaved-change handling applies to dismissal; do not silently discard financial drafts. Do not show a success toast before persistence is verified.

## 12. Desktop density and accessibility

| Viewport | Layout behavior |
| --- | --- |
| 1366 x 768 | Sidebar about 216 px, header 56 px, content padding 24 px; about 1100 px usable task width. Two-column form only when fields retain adequate width. Long worksheets scroll horizontally; keep 14 px table text. |
| 1920 x 1080 | Sidebar about 232 px, same text/control scale, 24-32 px content padding. Financial tables use available width; ordinary form width caps around 840-960 px. Normal content may cap around 1560 px. Do not enlarge every card to fill the display. |
| Zoom / narrower content | Reflow labels and normal forms to one column below about 760 px available form width. Sidebar collapses to a labeled menu when it obstructs content; it must not force tiny type. Table regions retain a keyboard-accessible horizontal scroll. |

Keep the active stage action visible near the form end; a sticky footer is acceptable if it does not cover fields, errors or table totals. Do not fix the whole page height and hide content. Avoid multiple nested vertical scroll containers. Print omits navigation, preserves identity/period/copy/read-only labels, repeats table headers and does not crop accounting columns.

Keyboard: logical order, visible focus, no hover-only menus, native control semantics, no navigation traps. Dialog focus returns to its trigger; selection and expansion have programmatic states. Tables have captions, scoped column/row headers and meaningful amount labels. Announce validation summaries and async feedback appropriately. Required/error text links to fields. Status is words plus icon/color. Tooltip information is available by keyboard/focus and is not the only place a critical limitation is explained. Respect reduced motion; no essential information relies on animation.

## 13. Review and handoff limits

The 24 extension frames are canonical visual concepts, not a complete state inventory or running system. Component rules cover unmocked loading, missing, empty, error, stale, historical and permission states. Do not treat an image's tiny generated text, chart shape, proposed version number or helper label as accounting truth.

Before any later implementation prompt, the main project-review chat should resolve the control warnings, reconcile unpushed source differences if material, and approve the extension. A later runnable prototype needs human task tests at both desktop sizes plus keyboard, zoom, focus, table-scroll, error-recovery and screen-reader checks. No client acceptance or final accessibility compliance is claimed here.
