# Atikha Finance - Refined Client Experience

This package is for external exact-source/browser review, not deployment or client acceptance.
Baseline: main / db15b542a45c3c6e88ee9ccab78e8adc9c700f4c. No commit or push.

1. Read documents/presentation-redesign-delivery.md and design/precedence.json.
2. Open index.html for before/after full-page screens. PNGs may be opened directly.
3. Inspect final/ and evidence/changed-files.json. baseline/ contains Git-baseline bytes only for the patch scope; preexisting user documentation is separately preserved.
4. Inspect evidence/test-summary.json, source pins, performance results, preservation summaries and limitations. Earlier failed attempts are retained in the ordinary original results and explained in delivery; do not count them as passing final runs.
5. Read documents/design-qa.md, fresh human protocol and unperformed working rollout procedure.

Verify without the application/database:

    python verify_package.py this-package.zip --reconstruct

Or run against the extracted directory. Requires Python 3 and Git for --reconstruct. The verifier changes only a temporary directory. No configuration, database dump, session, private receipt or provider secret is included. The source copy excludes operational db_connect.php/config.php and third-party PHP vendor dependencies; this is a review package, not a runnable installation.

R0-R8 source implementation/review delivery is complete. External review, actual screen-reader/physical zoom checks, fresh human walkthrough, working rollout and Atikha acceptance remain separate. Old Stage4-7 G7 remains paused/incomplete.
