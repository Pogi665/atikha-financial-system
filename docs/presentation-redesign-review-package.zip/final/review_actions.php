<?php

/**
 * Review workflow JSON endpoint: send for review / mark as reviewed.
 */

session_start();

require_once __DIR__ . '/db_connect.php';
require_once __DIR__ . '/includes/csrf.php';
require_once __DIR__ . '/includes/logger.php';
require_once __DIR__ . '/includes/notifications.php';
require_once __DIR__ . '/includes/report_snapshots.php';
require_once __DIR__ . '/includes/budget_revisions.php';
require_once __DIR__ . '/includes/report_bundles.php';

header('Content-Type: application/json; charset=utf-8');

const REVIEW_WORKSPACE_ROLES = ['Admin'];
const REVIEW_MANAGEMENT_ROLES = ['Management'];

/**
 * @param array<string, mixed>|null $data
 */
function review_respond(bool $ok, ?array $data, string $error, int $status = 200): void
{
    http_response_code($status);
    echo json_encode(['ok' => $ok, 'data' => $data, 'error' => $error], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    review_respond(false, null, 'This endpoint accepts POST requests only.', 405);
}

require_once __DIR__ . '/includes/user_session.php';
try {
    $sessionValid = user_session_validate($pdo);
} catch (Throwable $e) {
    error_log('Session validation failed: ' . $e->getMessage());
    review_respond(false, null, 'Account access is temporarily unavailable. Please try again.', 503);
}

if (!$sessionValid) {
    review_respond(false, null, 'Your session expired. Please sign in again.', 401);
}

if (!csrf_verify(is_string($_POST['csrf_token'] ?? null) ? $_POST['csrf_token'] : null)) {
    review_respond(false, null, 'Your session expired. Please reload the page and try again.', 400);
}

$userId = (int) $_SESSION['UserID'];
$role = (string) ($_SESSION['Role'] ?? '');
$action = is_string($_POST['action'] ?? null) ? $_POST['action'] : '';
$entityType = is_string($_POST['entity_type'] ?? null) ? $_POST['entity_type'] : '';
if (in_array($entityType, ['fund', 'expense'], true)) {
    review_respond(false, null, 'Legacy transaction reviews have been retired. Use General Journal.', 410);
}
if ($entityType === 'board') { review_respond(false, null, 'Internal Board messaging is retired. Historical messages are read only; use Email for correspondence.', 410); }
if ($entityType === 'report') {
    review_respond(false, null, 'Legacy summary reports are read-only. Submit a frozen Trial Balance revision.', 410);
}
if ($entityType === 'budget_revision') {
    try{
        if(!in_array($action,['approve_budget','return_budget'],true))review_respond(false,null,'Choose Approve budget or Return budget.',400);
        $request=$_POST;$request['decision']=$action==='approve_budget'?'Approved':'Returned';$result=budget_review($pdo,$userId,$request);
        review_respond(true,['entity_type'=>'budget_revision','entity_id'=>$result['id'],'review_status'=>$request['decision'],'duplicate'=>$result['duplicate'],'warning'=>$result['warning'],'budget_url'=>'budgets.php?revision_id='.$result['id']],'');
    }catch(ReportingProblem $e){review_respond(false,null,$e->getMessage(),$e->status);}catch(Throwable $e){error_log('Budget review unavailable.');review_respond(false,null,'The budget decision could not be confirmed. Open the revision before trying again.',503);}
}
if ($entityType === 'complete_report') {
    try{
        if(!in_array($action,['review_complete_reports','return_complete_reports'],true))review_respond(false,null,'Choose Mark reviewed or Return complete reports.',400);
        $request=$_POST;$request['bundle_id']=$request['entity_id']??'';$request['decision']=$action==='review_complete_reports'?'Reviewed':'Returned';$result=report_bundle_review($pdo,$userId,$request);
        review_respond(true,['entity_type'=>'complete_report','entity_id'=>$result['id'],'review_status'=>$request['decision'],'duplicate'=>$result['duplicate'],'warning'=>$result['warning'],'bundle_url'=>'report_bundles.php?bundle_id='.$result['id']],'');
    }catch(ReportingProblem $e){review_respond(false,null,$e->getMessage(),$e->status);}catch(Throwable $e){error_log('Complete report review unavailable.');review_respond(false,null,'The review could not be confirmed. Open the frozen revision before trying again.',503);}
}
if ($entityType === 'trial_balance') {
    try {
        if ($action === 'send_for_review') {
            $result = report_snapshot_submit($pdo, $userId, $_POST);
            $status = 'Requested';
        } elseif ($action === 'mark_reviewed') {
            $result = report_snapshot_review($pdo, $userId, $_POST);
            $status = 'Reviewed';
        } else { review_respond(false, null, 'Unknown review action.', 400); }
        review_respond(true, ['entity_type'=>'trial_balance','entity_id'=>$result['id'],
            'review_status'=>$status,'duplicate'=>$result['duplicate'],'warning'=>$result['warning'],
            'snapshot_url'=>'reports.php?snapshot_id='.$result['id']], '');
    } catch (ReportProblem $e) { review_respond(false, null, $e->getMessage(), $e->status); }
    catch (InvalidArgumentException $e) { review_respond(false, null, $e->getMessage(), 400); }
    catch (Throwable $e) { error_log('Trial Balance review failed: '.$e->getMessage()); review_respond(false, null, 'Unable to save the Trial Balance review. No partial changes were saved.', 503); }
}
review_respond(false, null, 'Unknown review action or entity.', 400);
