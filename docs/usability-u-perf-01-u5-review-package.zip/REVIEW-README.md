# U-PERF-01 + U5 exact-source review

Baseline: main f50d79e3d2bf38072946fbfdf543b6699118ad84 (U2 Follow-Up).
Start with docs/usability-u-perf-01-u5-delivery.md and its current outcome. The later dated execution ledger preserves original confusion, failures and superseded pending statements.

source/ contains exact raw final copies of the ten changed production files, changed/new tests, pure adapter dependencies and selected unchanged reader/test references. Patches apply to the baseline checkout. This is an exact-source/evidence review bundle, not a deployable complete application. A full baseline checkout plus the included patches is required for connected reruns. Guarded private synthetic schema/fixtures, Playwright/Edge/PHP/MariaDB prerequisites and blocked external calls are still required. Do not run fixtures, migrations, login helpers or financial actions on a working database. No private config/session/fixture/database export or real evidence image is included.

Run `python verify_package.py` from this extracted directory to verify every manifest-tracked member. Run the five node adapters from source/; their actual packaged rerun output is in evidence/packaged-offline-checks.json. The included Python files parse and PHP/JS files lint independently; connected tests require the full application and disposable fixtures.

Production/test patches were forward-applied, reversed and reapplied on fresh baseline file trees without changing the repository index. evidence/patch-reconstruction.json records exact normalized Git blob identities. Raw file SHA-256 values identify copies including Windows line endings; patches represent Git-normalized LF content. These are different identities by design. Unchanged dependencies are marked as references in the manifest.

evidence/accepted-runs.json records each dated accepted run, source pins and final mismatch list. Some earlier component suites predate later isolated UI cleanups; they are not described as identical whole-source final reruns. integrated84/register91/readback27/CP4 48 and the five performance-path pins match current final production. The register91/readback27 aggregate explicitly retains its original old-selector failure. verification.log is selected actual accepted assertion output and sanitized commands, not an invented complete transcript. Private failed logs and instrumented traces remain retained privately; the delivery classifies their fixes.

Timing CSV retains raw first and five repeat samples. Human observations are separate from automation; no human times, aggregate action totals, unassisted success rate or client acceptance were invented. Original human captures are dated pre-fix/retest evidence; see screenshot index. All screenshots contain synthetic facts. Physical-device, cross-browser and production login/MFA acceptance were not established.

The manifest excludes itself to avoid a circular self-hash. The ZIP SHA-256 is published in the adjacent repository sidecar. No commit/push was performed. Final external exact-source review is pending.
