import hashlib,json,pathlib
root=pathlib.Path(__file__).resolve().parent
m=json.loads((root/'manifest.json').read_text(encoding='utf-8'))
actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p.name!='manifest.json'}
assert actual==set(m['files']), 'Unexpected or missing package member'
for n,x in m['files'].items():
 b=(root/n).read_bytes(); assert len(b)==x['bytes'] and hashlib.sha256(b).hexdigest()==x['sha256'],n
print('PASS:',len(actual),'manifest-tracked members')
