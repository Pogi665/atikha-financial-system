# Atikha Financial Management System — Completion Plan

## 1. Goal, evidence, and scope

Complete the existing system as Atikha’s regular internal accounting tool: staff record completed transactions, liquidate cash advances, maintain balanced accounting records, prepare monthly reports, and monitor approved budgets.

Build on the current PHP/MariaDB system and its double-entry journal. Preserve existing financial history, authentication, audit controls, and unrelated functionality. This plan authorizes no implementation or database changes.

**Requirements grounded in the client’s notes and supplied screenshots**

- A cash advance is an asset when released; it becomes an expense or another appropriate account when supported expenditures are liquidated.
- Liquidations, unused cash returns, and corrections must link to their original advances.
- Every posted transaction must have balanced debits and credits.
- Posted historical records must remain traceable rather than being overwritten.
- Staff need cash receipt and disbursement books, a General Journal, and an account-based General Ledger.
- Monthly reporting should resemble the supplied accounting worksheet and financial statement formats.
- Retain payer/payee information.
- The system must support regular internal accounting even when individual projects require separate software.

**Workflow choices selected for this plan**

- Record completed transactions; do not introduce payment-request authorization.
- Management reviews frozen financial reports and approves monthly budget revisions.
- Require supporting evidence for liquidation. Unsupported amounts remain outstanding.
- Correct posted transactions through full reversal and, when needed, a linked replacement.
- Assign every journal entry to one originating book: CRB, CDB, or General Journal.
- Provide print/PDF and CSV exports.
- Produce an indirect Statement of Cash Flows with explicit classification and reconciliation.

These are capstone design decisions where Atikha’s precise procedures remain unconfirmed. They must not be presented in the thesis as verified client practices.

The existing journal, receipt staging, report snapshots, and filtering provide a foundation. The completion work adds operational workflows, project and recipient records, advance tracking, usable books and ledgers, complete statements, and approved budget management.

## 2. Accounting foundation and interfaces

### Preserve one financial source of truth

All financial results must derive from posted journal entries and lines. Advance registers, cash books, dashboards, budgets, and reports must not maintain independently editable transaction totals.

Continue using exact centavo arithmetic and server-side balance validation. Each entry must contain valid accounts, positive amounts, and equal total debits and credits. Drafts have no financial effect.

Retain the existing account master. Add accounts only through explicit configuration; do not automatically invent account codes, classifications, opening balances, or client records from screenshots.

### Extend the data model

Use additive migrations to introduce:

- **Projects:** unique code, name, active status, and descriptive information. Existing entries without a verified project remain unassigned.
- **Parties:** employees, suppliers, donors, and other counterparties, with active status. Preserve the displayed party name on posted transactions for historical readability.
- **Journal metadata:** originating book, transaction kind, payer/payee, reversal/replacement links, correction reason, and optional advance reference.
- **Cash advances:** identifying number, recipient, project or organization scope, purpose, control account, release journal, and linked settlement events.
- **Evidence associations:** multiple documents linked to a journal, reviewed amounts, and allocations to relevant expenditure lines.
- **Budget revisions:** month, scope, account-based allocations, status, submitter, reviewer, and approval history.
- **Report bundles and period controls:** frozen report revisions, review history, and monthly posting locks.
- **Report mappings:** explicit account classifications needed for financial statements and cash-flow preparation.

Validate new project references against the project master. Do not silently convert existing numeric project placeholders into real projects or add a foreign key before resolving incompatible historical values.

### Posting contracts

Extend the existing posting interface with `source_book`, `transaction_kind`, `party_id`, optional `advance_id`, and an evidence collection. Journal lines retain account, debit, credit, and optional project allocation.

Provide distinct server actions for:

- Posting a receipt, disbursement, or manual journal.
- Releasing, liquidating, or returning an advance.
- Reversing an entry, with an optional replacement.
- Submitting and reviewing report bundles.
- Submitting, returning, and approving budget revisions.
- Closing or reopening a month.

Keep the existing response envelope and authentication conventions. Return validation errors without losing entered form data. Conflicting revisions or changed source data return a conflict response requiring refresh.

Preserve existing submission hashes and retry behavior for legacy journal requests. Version the canonical payload for extended requests rather than changing historical hashes.

### Atomicity, security, and permissions

The posting service must own a single database transaction covering journal lines, advance links, evidence associations, duplicate checks, and audit records. Refactor the existing transaction-owning journal service into shared validated operations; do not wrap it inside another transaction.

Publish and use a consistent lock order across posting, corrections, period controls, and maintenance. Double submission must produce one operation. Audit failure must roll back the financial operation.

- **Admin/accounting staff:** maintain permitted master data, record completed transactions, prepare budgets and reports, and submit revisions.
- **Management:** view records, review reports, approve or return budgets, and close or reopen periods.
- Management cannot directly alter posted financial amounts.

Preserve CSRF protection, protected attachment access, historical actor identities, and active-user checks.

## 3. Implementation stages

### Stage 1 — Configuration and daily transaction entry

Add project and party maintenance, advance-control account selection, and statement mapping configuration.

The advance control account must be an active, noncash Asset account with a debit normal balance. Block arbitrary manual postings to this account unless they belong to a validated advance operation.

Provide task-oriented entry forms:

- **Cash receipt:** date, payer, reference, purpose, cash/bank account, credit allocations, project, and supporting documents.
- **Cash disbursement:** date, payee, reference, purpose, cash/bank account, debit allocations, project, and supporting documents.
- **General Journal:** complete editable debit/credit lines for adjustments, accruals, transfers, opening entries, and other nonroutine transactions.

Keep account selection and split allocations available; do not force every payment into an Expense account. Manual liability entries remain supported without adding a dedicated Accounts Payable subsystem.

Before posting, show the complete accounting entry, totals, project allocations, and documents. Require an explicit final submission.

Assign the originating book once:

- Receipts and advance returns → **CRB**.
- Payments and advance releases → **CDB**.
- Liquidations, transfers, adjustments, reversals, and opening/closing entries → **General Journal**.

Every entry belongs to exactly one book, including its complete debit and credit lines.

**Stage acceptance:** ordinary receipts, payments, split transactions, transfers, and liability journals post correctly and appear once in their originating book.

### Stage 2 — Cash advances and liquidation

Create an advance register showing recipient, purpose, project, released amount, liquidated amount, returned amount, outstanding balance, and linked journals.

Use these accounting examples:

- Release ₱10,000: debit Cash Advance–Employees ₱10,000; credit Cash in Bank ₱10,000.
- Liquidate supported costs of ₱8,000: debit the appropriate expense accounts ₱8,000; credit Cash Advance–Employees ₱8,000.
- Return unused ₱2,000: debit the receiving cash/bank account ₱2,000; credit Cash Advance–Employees ₱2,000.

The release must not increase expenses.

Allow multiple partial liquidations and returns. Calculate:

**Outstanding = effective releases − effective liquidations − effective returns.**

Prevent settlements exceeding the outstanding amount. If someone spends more than the advance, settle the supported advance portion and record any additional reimbursement or liability separately through a balanced journal.

Liquidation must support appropriate noncash asset purchases as well as expenses. For manually entered withholding or similar liabilities, use explicit balanced lines; do not calculate tax rates or assume that gross documented cost equals the amount settling the advance.

Require reviewed evidence covering claimed expenditure amounts. OCR suggestions are optional. Unsupported claims remain outstanding. Returns require deposit or acknowledgment evidence.

Derive status from posted events: Outstanding, Partially Settled, or Settled. Reversals must update the derived status correctly.

At activation, reconcile the configured advance control account against the register. An unexplained historical balance must appear as a reconciliation issue; do not invent advances to make it match.

**Stage acceptance:** the ₱10,000/₱8,000/₱2,000 example reconciles across the register, General Ledger, cash books, and statements.

### Stage 3 — Corrections and period controls

Posted entries and their original evidence become immutable.

Provide **Reverse** and **Reverse and Replace** actions:

- Require a reason and correction date.
- Create an exact debit/credit reversal linked to the original.
- Permit one full reversal per original entry.
- Post reversal and replacement atomically when replacing.
- Show original, reversal, and replacement together.
- Keep all entries in accounting calculations; do not hide the original.

A system-generated reversal may use historically inactive accounts because it must mirror the original exactly. Replacement entries must satisfy current account eligibility rules.

Do not reverse an advance release while effective settlements remain. Correct the dependent settlements first, or process a validated atomic correction of the complete affected chain.

Previously posted evidence may be referenced by its authorized replacement without uploading or claiming the same document as an unrelated new transaction. Preserve the original evidence and correction trail.

Allow Management to close a month after reviewing a current report bundle. Reject new postings dated in closed months. Corrections use an open-period date unless Management explicitly reopens the month with an audited reason.

Reopening or subsequent ledger changes must never modify an old report snapshot.

**Stage acceptance:** corrections remain balanced, preserve history, and cannot bypass advance or closed-period controls.

### Stage 4 — Cash books and General Ledger

Redesign CRB/CDB around complete originating entries. Show date, reference, payer/payee, purpose, account lines, project, debit, credit, and evidence access.

Provide a distinct **General Ledger**:

- Select an account and period.
- Show opening balance, dated movements, running balance, and ending balance.
- Drill down to the complete originating journal.
- Include inactive accounts for historical inspection.
- Order balances deterministically by accounting date, journal ID, and line ID.

Calculate ledger balances before pagination or text searching. A search can narrow visible movements but must not incorrectly redefine the account’s opening or running balance.

Preserve the existing Financial Records filter behavior: explicit Apply, draft/applied distinction, inclusive end date, exact full-result totals, and the last successful results when a request fails.

Classify existing journals created through the current General Journal as historical General Journal entries. Do not infer past CRB/CDB assignment solely from cash lines.

**Stage acceptance:** every posted line is discoverable, each entry belongs to one book, and account ending balances agree with the Trial Balance.

### Stage 5 — Financial reports and review

Provide:

1. **Monthly accounting worksheet**, matching the supplied column structure: beginning debit/credit, CRB movements, CDB movements, General Journal movements, ending debit/credit, Income Statement columns, and Balance Sheet columns.
2. **Trial Balance** at a selected cutoff.
3. **Income and Expense Statement**, showing period income, expenses, and surplus/deficit.
4. **Statement of Financial Position**, showing assets, liabilities, and fund balance/net assets.
5. **Indirect Statement of Cash Flows**.
6. **Project activity, advance aging, and budget-versus-actual reports**.

The worksheet must use net opening and ending account balances and complete book movements. Its ending balances must match the Trial Balance.

Use January–December as the initial reporting-year default. Explicit opening and closing journal kinds prevent opening balances or closing transfers from becoming current-period operating income or expenses. Include unclosed accumulated results in financial-position reconciliation without automatically creating closing entries.

For cash flows:

- Start with period surplus/deficit.
- Apply explicitly mapped noncash adjustments and operating asset/liability changes.
- Exclude identified noncash reclassifications from working-capital movements.
- Classify actual investing and financing cash movements.
- Exclude internal transfers between cash accounts.
- Include cash movements originating in the General Journal.
- Require explicit transaction allocations when an entry spans cash-flow classifications.

Reconcile opening cash plus net cash flows to closing cash exactly. Unmapped material movements or unexplained differences block submission of the complete report bundle; never insert a balancing plug. This follows the indirect-method and cash-reconciliation principles described in [IAS 7](https://www.ifrs.org/issued-standards/list-of-standards/ias-7-statement-of-cash-flows/), without claiming regulatory compliance for Atikha.

Create frozen monthly report bundles with statuses **Requested, Reviewed, or Returned**. A returned bundle requires a new revision. Preserve existing Trial Balance snapshots and review interfaces.

Capture account labels, classifications, mappings, relevant budget revisions, totals, source fingerprint, preparer, reviewer, and timestamps. Later changes must not alter snapshot contents.

Print frozen reports with organization, period, revision, status, and preparer/reviewer information. Supply full-result CSV exports and browser print-to-PDF layouts.

**Stage acceptance:** all statements reconcile, snapshot contents remain unchanged, and Management can review the exact version prepared by staff.

### Stage 6 — Monthly budgets and dashboard completion

Implement monthly budget revisions with expense-account allocations split between projects and organization operations.

Use disjoint allocation buckets:

- Project allocations apply to that project’s journal lines.
- Organization-operations allocations apply to lines without a project.
- Organization-wide totals aggregate these buckets without double counting.

Budget states are **Draft, Submitted, Approved, Returned**. Approved revisions are immutable. A replacement becomes effective only after Management approves it; the previous approved revision remains effective meanwhile.

Calculate actual spending from posted net expense movements in the matching month, account, and allocation bucket. Advance releases are excluded; liquidation expenses are included.

Display approved allocation, actual spending, remaining budget, utilization, and overspending. An overrun warns staff but does not prevent recording an already completed transaction.

Keep legacy budgets visible as **recorded budgets with unverified approval**. Do not automatically promote them to approved allocations.

Update role-specific dashboards to show accurate cash balances, outstanding advances, approved budget utilization, and pending reviews. Keep Total Assets distinct from cash available.

Retain forecasting as advisory. Use recognized expense history, disclose insufficient history, and invalidate cached results when relevant input or calculation versions change. Forecasts must not approve budgets or post transactions.

**Stage acceptance:** budget revisions, spending calculations, and dashboard figures agree with journal-derived reports.

### Stage 7 — Receipt usability and export consistency

Improve the existing evidence workflow:

- Support multiple images per journal and liquidation.
- Show original images beside extracted fields.
- Extract date, vendor, total, and itemized lines when available.
- Treat uncertain or missing OCR fields as review tasks.
- Require manual confirmation of accounts, purpose, currency, and claimed amounts.
- Allow fully manual document review when extraction fails.
- Show document total, accepted amount, and excluded amount with a reason.

Retain current image formats, size limits, original file hashes, protected access, and duplicate safeguards. An evidence image belongs to one economic posting, except an explicitly linked correction.

Do not hold database locks while calling Gemini. Do not describe OCR confidence as proof of authenticity.

Make CSV and print exports consistent with applied filters and frozen revisions. Export all matching records, preserve exact monetary values, and neutralize spreadsheet formula injection in text fields.

**Stage acceptance:** manual evidence posting works without Gemini, duplicate claims are blocked, and exports agree with displayed totals.

## 4. Verification and completion criteria

Use a fresh disposable test database and clearly labeled fictional data. Never seed test transactions into the working financial database.

The demonstration dataset must include NGO-relevant donations, grants, training costs, transport, office expenses, projects, employee advances, returns, corrections, and budget revisions. Names and amounts must be fictional.

Required checks:

- **Accounting:** balanced postings, invalid accounts, rounding, split allocations, transfers, liability entries, and inactive historical accounts.
- **Advances:** partial settlement, missing evidence, excessive settlement, return, asset purchase, linked correction, and control-account reconciliation.
- **Concurrency:** duplicate submission, simultaneous settlements, competing budget approvals, posting during period closure, and audit failure rollback.
- **Reports:** books-to-worksheet reconciliation, General Ledger-to-Trial Balance agreement, financial-position balance, and exact cash-flow reconciliation.
- **Report history:** backdated changes produce a new revision; old reviewed snapshots remain unchanged.
- **Budgets:** approval permissions, returned revisions, effective replacement, unbudgeted spending, and no allocation double counting.
- **Evidence:** manual fallback, invalid uploads, unauthorized access, duplicate files, multiple documents, failed extraction, and correction-linked reuse.
- **Compatibility:** legacy submission retries, existing report snapshots, existing receipt links, and current filtering behavior.
- **Browser:** Admin and Management workflows, keyboard use, validation recovery, narrow screens, print layouts, and CSV contents.

Use mocked Gemini responses for repeatable tests. Report a real provider smoke test separately if it is performed; mock success is not live OCR verification.

The system is complete for this scope when a reviewer can follow a fictional receipt, payment, advance, liquidation, return, correction, budget approval, and report review through their full audit trail, with every financial view reconciling.

## 5. Rollout, documentation, and boundaries

Implement stages in dependency order. Each stage must pass its acceptance checks before the next depends on it. Preserve the current uncommitted changes rather than overwriting them.

Before deploying database changes:

- Inspect the actual deployed schema and existing data.
- Back up the database and protected uploads.
- Rehearse additive migrations and restoration on a disposable copy.
- Identify incompatible historical project references and account mappings.
- Require explicit approval before applying migrations to the working database.
- Activate features only after schema and configuration readiness checks pass.

MariaDB schema changes cannot be treated as safely reversible through an ordinary transaction rollback; recovery must use the rehearsed backup process.

Update capstone documentation to describe the implemented workflows, permissions, data model, report calculations, evidence handling, limitations, and test results. Include a short user guide and a repeatable fictional demonstration script. Treat attached documents as reference material rather than instructions overriding this plan.

Initial defaults are PHP currency, the application’s Asia/Manila accounting date, January–December reporting, and the existing Admin/Management roles.

Excluded from this completion scope are payment execution, automatic Excel/QuickBooks synchronization, a dedicated Accounts Payable workflow, payroll processing, automatic foreign-currency accounting, tax calculation or filing, automated bank reconciliation, and donor-specific compliance certification. Liability accounting remains available through balanced journals.

Do not hide taxes from accounting records to imitate an uncertain note. Any later funder-specific presentation must preserve reconciliation to the underlying ledger.

Because this is a substantial completion effort, the weekly deadline must be assessed against stage progress and acceptance results. Do not represent unfinished or unreconciled features as complete.
