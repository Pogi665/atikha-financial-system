"""Verify this static planning package; not an application/DB test."""
import hashlib,json,sys,zipfile
from pathlib import Path
path=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).parent
if path.is_file():
    with zipfile.ZipFile(path) as z:
        members={n:z.read(n) for n in z.namelist() if not n.endswith('/')}
else:
    members={str(p.relative_to(path)).replace('\\','/'):p.read_bytes() for p in path.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
manifest=json.loads(members['MANIFEST.json'])
assert set(members)==set(manifest['files'])|{'MANIFEST.json'},'Unexpected/missing members'
for name,entry in manifest['files'].items():
    data=members[name]
    assert len(data)==entry['bytes'] and hashlib.sha256(data).hexdigest()==entry['sha256'],name
print(str(len(manifest['files']))+'/'+str(len(manifest['files']))+' manifest-tracked planning members passed; no runtime tests were run.')
